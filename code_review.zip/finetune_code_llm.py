import torch
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
import wandb
import random
from trl import DataCollatorForCompletionOnlyLM
import json
from peft import LoraConfig, PeftModel, get_peft_model
import copy
import os

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

new_model_name = "finetuned_ioana_codellama" #"finetuned_ioana_codegemma_no_linter"
model_name = "meta-llama/CodeLlama-7b-Instruct-hf"

wandb.login(key=os.environ["WANDB_TOKEN"])
wandb.init(
    project="R-Code-Translations",
    config={
        'base_model': model_name,
        'model_name': new_model_name,
        'dataset': 'Dataset 1, Step 1',
    }
)

data_train = json.load(open("R-Code-Translations/llama_changed_filtered_train.json", "r"))

data_test = copy.deepcopy(data_train)[:1000]
random.shuffle(data_train)

# Convert to dataset
train_dataset = Dataset.from_list(data_train)
test_dataset = Dataset.from_list(data_test)

tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side="left", token=os.environ["HF_TOKEN"])
tokenizer.pad_token_id = tokenizer.bos_token_id

def tokenize_function(examples):
    messages = [
        {"role": "system", "content": "You are an R coding expert."},
        {"role": "user", "content": f"{examples['question']}"},
        {"role": "assistant", "content": f"```r\n{examples['response']}\n```"}
    ]
    text_example = tokenizer.apply_chat_template(messages, add_special_tokens=False, tokenize=False)
    inputs = tokenizer(text_example, return_tensors="pt", max_length=2048*2, truncation=True, padding=True).to(device)
    inputs["attention_mask"] = inputs["attention_mask"].squeeze()
    inputs["input_ids"] = inputs["input_ids"].squeeze()
    inputs["no_tokens"] = inputs["input_ids"].shape[0]

    return inputs

train_dataset_tokenized = train_dataset.map(lambda x: tokenize_function(x))
test_dataset_tokenized = test_dataset.map(lambda x: tokenize_function(x))

print(len(train_dataset_tokenized))
print(len(test_dataset_tokenized))

# Filter out examples that are too long
train_dataset_tokenized = train_dataset_tokenized.filter(lambda x: x['no_tokens'] <= 4000)
test_dataset_tokenized = test_dataset_tokenized.filter(lambda x: x['no_tokens'] <= 4000)

print(len(train_dataset_tokenized))
print(len(test_dataset_tokenized))

# Drop all columns except input_ids, attention_mask and labels
train_dataset_tokenized.set_format(type='torch', columns=['input_ids', 'attention_mask'])
test_dataset_tokenized.set_format(type='torch', columns=['input_ids', 'attention_mask'])

model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", token=os.environ["HF_TOKEN"])

CODELLAMA_TEMPLATE = "[/INST]"
CODEGEMMA_TEMPLATE = "<end_of_turn>\n<start_of_turn>model"

trainer = Trainer(
    model=model,
    train_dataset=train_dataset_tokenized,
    eval_dataset=test_dataset_tokenized,
    tokenizer=tokenizer,
    args=TrainingArguments(
        gradient_accumulation_steps=32,
        per_device_train_batch_size=2,
        per_device_eval_batch_size=2,
        bf16=True,
        dataloader_num_workers=128,
        num_train_epochs=10,
        learning_rate=1e-6,
        lr_scheduler_type="constant",
        logging_steps=1,
        evaluation_strategy="steps",
        eval_steps=0.2,
        optim="adamw_8bit",
        report_to="wandb",
        output_dir=f"logs_{new_model_name}",
        save_steps=0.2,
        save_total_limit=1,
    ),
    data_collator=DataCollatorForCompletionOnlyLM(tokenizer=tokenizer, mlm=False, return_tensors="pt", response_template=CODELLAMA_TEMPLATE)
)

trainer.train()

# Save trained model
trainer.save_model(new_model_name)
tokenizer.save_pretrained(new_model_name)
