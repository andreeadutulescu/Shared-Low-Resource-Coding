import json
from tqdm import tqdm
from vllm import LLM
from vllm.sampling_params import SamplingParams
import torch
import os

LANGUAGE = "r" # python r
MODEL = "custom" # deepseek llama qwen phi4 codestral codegemma codellama

params = SamplingParams(max_tokens=8128, seed=100)

if MODEL == "codegemma":
    model_name = "google/codegemma-7b-it"
elif MODEL == "codellama":
    model_name = "meta-llama/CodeLlama-7b-Instruct-hf"
else:
    model_name = MODEL
    
llm = LLM(
    model=model_name,
    dtype=torch.bfloat16, 
    max_model_len=8128,
    enable_prefix_caching=True,
)

if MODEL not in ['codellama', 'codegemma']:
    task_prompt = ""
    print("No task prompt for this model")
else:
    task_prompt = f"Implement the following {LANGUAGE.capitalize()} function. Do not import any additional libraries or packages."
    print(f"Using task prompt")

dataset = json.load(open(f"R-Code-Translations/evaluation_data/reshaped_{LANGUAGE}_humaneval_test.json"))

new_prompts = []
for data in dataset:
    if MODEL == "custom":
        messages = [
            {"role": "system", "content": "You are an R coding expert."},
            {"role": "user", "content": f"{data['prompt']}"}
        ]
    else:
        prompt = f"{task_prompt}\n\n{data['prompt']}"    
        messages = [
            {"role": "user", "content": prompt},
        ]
    new_prompts.append(messages)

batch_size = 16
all_responses = []
for i in tqdm(range(0, len(new_prompts), batch_size)):
    end_idx = min(i + batch_size, len(new_prompts))
    messages = new_prompts[i:end_idx]

    responses = llm.chat(messages, params, use_tqdm=False)
    responses_text = []
    for response in responses:
        responses_text.append(response.outputs[0].text)

    all_responses += responses_text
    
for data, response in zip(dataset, all_responses):
    try:
        if f"```{LANGUAGE.capitalize()}" in response:
            response = response.replace(f"```{LANGUAGE.capitalize()}", f"```{LANGUAGE}")

        code = response.split(f"```{LANGUAGE}")[1].split("```")[0]
        code = code.strip()
    except:
        if '```' in response:
            code = response.split('```')[1].strip()
        else:
            code = None

    data['code'] = code
    data['response'] = response

json.dump(dataset, open(f"R-Code-Translations/evaluation_data/{MODEL}_{LANGUAGE}_humaneval_test_generated.json", "w"), indent=4)